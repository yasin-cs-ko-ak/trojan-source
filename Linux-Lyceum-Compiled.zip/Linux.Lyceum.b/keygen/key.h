#define KEY "qjjomdhbcvzkvdalmg"
